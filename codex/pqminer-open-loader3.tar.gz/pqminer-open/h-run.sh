#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
. ./h-manifest.conf
mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"
[[ -f $CUSTOM_CONFIG_FILENAME ]] || { echo "pqminer-open: run h-config.sh first" >&2; exit 1; }
mapfile -t args < "$CUSTOM_CONFIG_FILENAME"
export PQ_COLOR=1
unset PQ_PROFILE PQ_CPU_TEST
exec ./pqminer "${args[@]}" --api-port "$MINER_API_PORT" --log-file "${CUSTOM_LOG_BASENAME}.log" 2>&1
