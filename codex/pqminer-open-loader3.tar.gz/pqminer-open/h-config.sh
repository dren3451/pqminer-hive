#!/usr/bin/env bash
# Hive sources this file. Public package: scripts only; binary stays private.
pq_open_fetch() {
    local token=$1 miner_dir=$2
    local artifact_ref=ac1e2a4341d141020189cea3c422977741da9fcb
    local archive_sha=6bea6a194f6c64f91a79b37fd9682deadc84339e102e0677106ea7195a8a0432
    local binary_sha=c8910601cb1514054e0686aa271064351b938ff84459af44887dfb6b8c6f6e41
    local artifact_path=hive-artifacts/pqminer-open-0.1.7-open4.tar.gz
    local tmp actual
    if [[ -x $miner_dir/pqminer ]]; then
        actual=$(sha256sum "$miner_dir/pqminer")
        [[ ${actual%% *} == "$binary_sha" ]] && return 0
    fi
    tmp=$(mktemp -d) || return 1
    echo "pqminer-open: downloading the pinned private build"
    if ! curl -fsSL --retry 2 --connect-timeout 10 --max-time 180 \
        -H "Authorization: Bearer $token" -H "Accept: application/vnd.github.raw+json" \
        -o "$tmp/payload.tgz" \
        "https://api.github.com/repos/dren3451/pqminer/contents/$artifact_path?ref=$artifact_ref"; then
        rm -rf "$tmp"
        echo "pqminer-open: private download failed; check token Contents: Read-only access to dren3451/pqminer" >&2
        return 1
    fi
    if ! printf '%s  %s\n' "$archive_sha" "$tmp/payload.tgz" | sha256sum -c --status; then
        rm -rf "$tmp"
        echo "pqminer-open: payload checksum mismatch" >&2
        return 1
    fi
    if ! tar -xzf "$tmp/payload.tgz" -C "$tmp" || [[ ! -f $tmp/pqminer-open/pqminer ]]; then
        rm -rf "$tmp"
        echo "pqminer-open: invalid private payload" >&2
        return 1
    fi
    actual=$(sha256sum "$tmp/pqminer-open/pqminer")
    if [[ ${actual%% *} != "$binary_sha" ]]; then
        rm -rf "$tmp"
        echo "pqminer-open: binary checksum mismatch" >&2
        return 1
    fi
    if ! install -m 755 "$tmp/pqminer-open/pqminer" "$miner_dir/pqminer.new" ||
        ! mv -f "$miner_dir/pqminer.new" "$miner_dir/pqminer"; then
        rm -rf "$tmp"
        return 1
    fi
    cp "$tmp/pqminer-open/NOTICE" "$tmp/pqminer-open/BUILD_INFO" "$miner_dir/"
    cp -R "$tmp/pqminer-open/licenses" "$miner_dir/"
    rm -rf "$tmp"
}

pq_open_config_main() {
    local miner_dir=${PQ_OPEN_DIR:-/hive/miners/custom/pqminer-open} gh_token
    if [[ -z $CUSTOM_CONFIG_FILENAME ]]; then
        . /hive/miners/custom/pqminer-open/h-manifest.conf
    fi
    gh_token=$(python3 - "$CUSTOM_USER_CONFIG" <<'PY'
import shlex, sys
try:
    words = shlex.split(sys.argv[1])
    token = ''
    for i, word in enumerate(words):
        if word == '--gh-token':
            if i + 1 >= len(words):
                raise ValueError('missing --gh-token value')
            token = words[i + 1]
        elif word.startswith('--gh-token='):
            token = word.split('=', 1)[1]
    print(token, end='')
except ValueError:
    print('pqminer-open: invalid Extra config arguments', file=sys.stderr)
    sys.exit(1)
PY
    ) || return 1
    [[ -z $gh_token && -f /hive-config/pqminer.token ]] && gh_token=$(< /hive-config/pqminer.token)
    if [[ -z $gh_token ]]; then
        echo "pqminer-open: add --gh-token github_pat_... to Extra config arguments" >&2
        return 1
    fi
    mkdir -p "$miner_dir" || return 1
    pq_open_fetch "$gh_token" "$miner_dir" || return 1
    python3 - "$CUSTOM_CONFIG_FILENAME" "$CUSTOM_URL" "$CUSTOM_TEMPLATE" \
        "$WORKER_NAME" "$CUSTOM_PASS" "$CUSTOM_USER_CONFIG" <<'PY'
import os, pathlib, shlex, sys
filename, pools, wallet, worker, password, extra = sys.argv[1:]
try:
    words = shlex.split(extra)
    rest = []
    i = 0
    while i < len(words):
        w = words[i]
        # Loader options must not reach the miner config or its logs.
        if w in ('--gh-token', '--pqminer-version'):
            if i + 1 >= len(words):
                raise ValueError('missing value for a loader option')
            i += 2
            continue
        if w.startswith(('--gh-token=', '--pqminer-version=')):
            i += 1
            continue
        rest.append(w)
        i += 1
    args = ['--algorithm', 'pearl', '--pearl-kernel', 'legacy']
    for url in shlex.split(pools):
        args.extend(['--pool', url])
    if wallet:
        args.extend(['--wallet', wallet])
    if worker:
        args.extend(['--worker', worker])
    if password:
        args.extend(['--password', password])
    args.extend(rest)
    if any('\n' in w or '\r' in w or '\0' in w for w in args):
        raise ValueError('a config argument contains an unsupported control character')
    out = pathlib.Path(filename)
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.name + '.new')
    tmp.write_text(''.join(w + '\n' for w in args))
    os.chmod(tmp, 0o600)
    os.replace(tmp, out)
except (ValueError, OSError) as exc:
    print('pqminer-open: cannot build config: ' + str(exc), file=sys.stderr)
    sys.exit(1)
PY
}
pq_open_config_main
