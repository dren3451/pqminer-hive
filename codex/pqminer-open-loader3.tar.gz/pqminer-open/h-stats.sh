#!/usr/bin/env bash
# Sourced by Hive; read only this miner's independent API.
. /hive/miners/custom/pqminer-open/h-manifest.conf
pq_open_stats_main() {
    local stats_raw
    stats_raw=$(curl --connect-timeout 2 --max-time 5 --silent --noproxy '*' "http://127.0.0.1:${MINER_API_PORT}/")
    if [[ $? -ne 0 || -z $stats_raw ]]; then
        khs=0
        stats=null
        return
    fi
    khs=$(jq -r '.hive.khs // 0' <<< "$stats_raw")
    stats=$(jq -c '.hive.stats // null' <<< "$stats_raw")
    [[ -z $khs ]] && khs=0
    [[ -z $stats ]] && stats=null
    return 0
}
pq_open_stats_main
